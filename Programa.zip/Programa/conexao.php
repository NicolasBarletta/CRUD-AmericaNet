<?php
$servername = "localhost";
$database = "controle_up";
$username = "root";
$password = "";

$conexao = mysqli_connect($servername, $username, $password, $database);


?>