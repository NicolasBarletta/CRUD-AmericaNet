<?php
$cpfCliente = $_POST['cpfCliente'];
$nomeCliente = $_POST['nomeCliente'];
$planoAntigo = $_POST['planoAntigo'];
$planoNovo = $_POST['planoNovo'];
$qtdChip = $_POST['qtdChip'];
$dataUp = $_POST['dataUp'];

echo $cpfCliente;

?>